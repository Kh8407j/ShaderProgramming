"ShaderToy shader -1" provided by None
https://www.shadertoy.com/new
-------------------------------------------------------------
{tags}
For university labtask coursework purposes!
-------------------------------------------------------------
You can upload the JSON file of the shader using
https://github.com/patuwwy/ShaderToy-Chrome-Plugin
