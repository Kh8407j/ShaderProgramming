"labtask3" provided by unknown
https://www.shadertoy.com/new
-------------------------------------------------------------
Tags: heatmap, university

For university coursework!
-------------------------------------------------------------
You can upload the JSON file of the shader using
https://github.com/patuwwy/ShaderToy-Chrome-Plugin
